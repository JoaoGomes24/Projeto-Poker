#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "pokeristars.h"

char ranks[MAX_RANKS];
char suits[MAX_SUITS];

void runCommandLine(int nr_Cards, char *argv[]){

  switch (nr_Cards) {
    case 5:

    inicializeCards5and10(nr_Cards);
    int Duplicate_5 = checkDuplicates(0, nr_Cards);
    int Invalid_5 = validateCards(0, nr_Cards);

    if(Duplicate_5 == -1 || Invalid_5 == -1){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "-1\n");
      }else{
        printf("-1\n");
      }

      if(*TestMode == 'd'){         //Caso a opcao de funcionamento seja -d, as cartas ilegais tem de contar para as estatisticas
        checkHand(-1);
      }else if(*TestMode != 'd'){   //Caso a opcao de funcionamento seja -c, as cartas ilegais param o programa
        exit(0);
      }break;
    }

    ordenateCards(0, nr_Cards);
    int hand5 = handValue(0, CardPoints);

    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "%d\n",hand5);
    }else{
      printf("%d\n", hand5);
    }

    checkHand(hand5);       //Vai aumentar a contagem da determinada mao para se fazer as estatisticas
      break;

    case 7:

    inicializeCards7(nr_Cards);

    if(argv[1][2] != 'x'){    //Caso o modo de funcionamento seja o -dx, nao exite cartas ilegais, logo nao e necessario correr esta parte do codigo
      int Duplicate_7 = checkDuplicates(0, nr_Cards);
      int Invalid_7 = validateCards(0, nr_Cards);

      if(Duplicate_7 == -1 || Invalid_7 == -1){
        if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
          fprintf(Write, "-1\n");
        }else{
          printf("-1\n");
        }
        if(*TestMode == 'd'){
          checkHand(-1);
        }else if(*TestMode != 'd'){
          exit(0);
        }break;
      }
    }

    int hand7 = bestHandPossible(0, nr_Cards, argv);

    if(argv[1][2] == 'x'){
      if(Fold[PlayerPosition-1] != 4){    //Verifica se o jogador ainda pode fazer fold, pois para isso tem de o ter feito menos de 4 vezes seguidas
        if(hand7 < PlayerPosition){
          Fold[PlayerPosition-1]++;        //Inicializaçoes para quem faz fold, aumenta-se a contagem de folds para o jogador em questao
          DidFold[PlayerPosition-1] = 1;
          Plays[PlayerPosition-1] = 0;     //Coloca as idas a jogo a 0
          InGame[PlayerPosition-1] = 0;
          return;
        }
      }else if(Fold[PlayerPosition] == 4){  //Caso tenha feito 4 Folds, e obrigado a ir a jogo
        Fold[PlayerPosition-1] = 0;          //Inicializaçoes para quem vai a jogo pela primeira vez
        DidFold[PlayerPosition-1] = 0;
        Plays[PlayerPosition-1] = 0;
        InGame[PlayerPosition-1] = 0;
      }
      Fold[PlayerPosition-1] = 0;         //Inicializaçoes para quem vai a jogo
      DidFold[PlayerPosition-1] = 0;
      Plays[PlayerPosition-1]++;
      InGame[PlayerPosition-1] = 0;       //Caso nao va colocava-se "-1" na posicao indicada
      bestExtraMode(hand7, argv);
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "%d ", PlayerPosition);
      }else{
        printf("%d ", PlayerPosition);
      }
    }

    printCards1(hand7, argv);

    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "%d\n",hand7);
    }else{
      printf("%d\n", hand7);
    }

    if(argv[1][2] != 'x'){
      checkHand(hand7);
    }
      break;

    case 9:

    inicializeFirstCards9(nr_Cards);
    int Duplicate_9 = checkDuplicates(0, nr_Cards);
    int Invalid_9 = validateCards(0, nr_Cards);

    if(Duplicate_9 == -1 || Invalid_9 == -1){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "-1\n");
      }else{
        printf("-1\n");
      }

      if(*TestMode == 'd'){
        checkHand(-1);   // Sempre que e -1 temos de colocar duas vezes, pois sao duas maos
        checkHand(-1);
        checkWinner(0); //Caso haja maos ilegais considera-se empate
      }else if(*TestMode != 'd'){
        exit(0);
      }break;
    }

    int hand1_9 = bestHandPossible(0, nr_Cards-2, argv);
    printCards1(hand1_9, argv);

    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "%d ",hand1_9);
    }else{
      printf("%d ", hand1_9);
    }

    inicializeSecCards9(nr_Cards);
    int hand2_9 = bestHandPossible(0, nr_Cards-2, argv);
    printCards2(hand2_9, argv);

    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "%d ",hand2_9);
    }else{
      printf("%d ", hand2_9);
    }

    checkHand(hand1_9);
    checkHand(hand2_9);

    for(int i = 0; i < 5; i++){
      strcpy(Cards[i], Temp[i]);
      strcpy(Cards[i+5], Temp[i+5]);}

      ordenateCards(0, nr_Cards-4);
      ordenateCards(5, nr_Cards+1);
      int winner_9 = clashResult(hand1_9, hand2_9);

      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "%d\n", winner_9);
      }else{
        printf("%d\n", winner_9);
      }

      checkWinner(winner_9);  //Vai aumentar a contagem do determinado vencedor para se fazer as estatisticas
      break;

    case 10:

      inicializeCards5and10(nr_Cards);
      int Invalid_10_1 = validateCards(0, nr_Cards/2);
      int Invalid_10_2 = validateCards(5, nr_Cards);
      int Duplicate_10_1 = checkDuplicates(0, nr_Cards/2);
      int Duplicate_10_2 = checkDuplicates(5, nr_Cards);

      if(Invalid_10_1 == -1 || Invalid_10_2 == -1 || Duplicate_10_1 == -1 || Duplicate_10_2 == -1){
        if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
          fprintf(Write, "-1\n");
        }else{
          printf("-1\n");
        }

        if(*TestMode == 'd'){
          checkHand(-1);
          checkHand(-1);
          checkWinner(0);
        }else if(*TestMode != 'd'){
          exit(0);
        }
        return;
      }

      ordenateCards(0, nr_Cards/2);
      int hand10_1 = handValue(0, CardPoints);
      ordenateCards(5, nr_Cards);
      int hand10_2 = handValue(5, CardPoints);

      checkHand(hand10_1);
      checkHand(hand10_2);

      int winner_10 = clashResult(hand10_1, hand10_2);

      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "%d\n",winner_10);
      }else{
        printf("%d\n", winner_10);
      }

      checkWinner(winner_10);
      break;

      default:
      printf("-1\n");
      break;
    }
  }

void inicializeCards5and10(int nr_Cards){

    for (int i=0; i < nr_Cards; i++){
      strcpy(Cards[i], AnallyseHand[i]); // Colocar os argumentos(cartas) no vetor Cards
    }
  }

void inicializeCards7(int nr_Cards){

    for (int i=0; i < nr_Cards; i++){
      strcpy(Cards2[i], AnallyseHand[i]); // Colocar os argumentos(cartas) no vetor Cards2
    }
  }

void inicializeFirstCards9(int nr_Cards){

    for (int i=0; i < 2; i++){
      strcpy(Cards2[i], AnallyseHand[i]); // Colocar os primeiros 2 argumentos(cartas) no vetor Cards2
    }

    for (int i=2; i < nr_Cards-2; i++){
      strcpy(Cards2[i], AnallyseHand[i+2]); // Colocar os ultimos 5 argumentos(cartas) no vetor Cards2, para analisar a melhor mao possivel do primeiro jogador
    }
  }

void inicializeSecCards9(int nr_Cards){

    for (int i=0; i < nr_Cards-2; i++){
      strcpy(Cards2[i], AnallyseHand[i+2]); // Colocar os ultimos 7 argumentos(cartas) no vetor Cards2, para analisar a melhor mao possivel do segundo jogador
    }
  }

void changePositions1(void){ // Coloca-se o A no fim do vetor PossibleHand2, quando se da o menor straight/straightFlush do jogo

    char aux[3];

    if(PossibleHand2[0][0] == 'A' && PossibleHand2[1][0] == '5' && PossibleHand2[2][0] == '4' && PossibleHand2[3][0] == '3' && PossibleHand2[4][0] == '2'){
      for (int i = 0; i < 5; i++){
        for(int j = i + 1; j < 5; j++){
          strcpy(aux, PossibleHand2[i]);
          strcpy(PossibleHand2[i], PossibleHand2[j]);
          strcpy(PossibleHand2[j], aux);
        }
      }
      for (int i = 0; i < 4; i++){
        for(int j = i + 1; j < 4; j++){
          strcpy(aux, PossibleHand2[i]);
          strcpy(PossibleHand2[i], PossibleHand2[j]);
          strcpy(PossibleHand2[j], aux);
        }
      }
    }
  }

void changePositions2(int init){ // Coloca-se o A no fim do vetor Cards, quando se da o menor straight/straightFlush do jogo

    char aux[3];
    int aux2;

    if(Cards[init][0] == 'A' && Cards[init+1][0] == '5' && Cards[init+2][0] == '4' && Cards[init+3][0] == '3' && Cards[init+4][0] == '2'){
      for (int i = init; i < init + 5; i++){
        for(int j = i + 1; j < init + 5; j++){
          strcpy(aux, Cards[i]);
          strcpy(Cards[i], Cards[j]);
          strcpy(Cards[j], aux);

        }
      }
      for (int i = init; i < init + 4; i++){
        for(int j = i + 1; j < init + 4; j++){
          strcpy(aux, Cards[i]);
          strcpy(Cards[i], Cards[j]);
          strcpy(Cards[j], aux);
        }
      }
    }

    // Ordena-se o CardsRanks para a nova formatacao do vetor Cards

    if((CardsRanks[init] == 13 && CardsRanks[init+1] == 4 && CardsRanks[init+2] == 3 && CardsRanks[init+3] == 2 && CardsRanks[init+4] == 1) ||
    (CardsRanks[init] == 4 && CardsRanks[init+1] == 3 && CardsRanks[init+2] == 2 && CardsRanks[init+3] == 1 && CardsRanks[init+4] == 13)){
      for (int i = init; i < init + 5; i++){
        for(int j = i + 1; j < init + 5; j++){
          aux2 = CardsRanks[i];
          CardsRanks[i] = CardsRanks[j];
          CardsRanks[j] = aux2;
        }
      }
      for (int i = init; i < init + 4; i++){
        for(int j = i + 1; j < init + 4; j++){
          aux2 = CardsRanks[i];
          CardsRanks[i] = CardsRanks[j];
          CardsRanks[j] = aux2;
        }
      }
    }
  }

bool isPair(int init, int *CardPoints, bool pair){

    if((CardPoints[init]-CardPoints[init+1]<4 && CardPoints[init+1]-CardPoints[init+2]>4 && CardPoints[init+2]-CardPoints[init+3]>4 && CardPoints[init+3]-CardPoints[init+4]>4)
    || (CardPoints[init]-CardPoints[init+1]>4 && CardPoints[init+1]-CardPoints[init+2]<4 && CardPoints[init+2]-CardPoints[init+3]>4 && CardPoints[init+3]-CardPoints[init+4]>4)
    || (CardPoints[init]-CardPoints[init+1]>4 && CardPoints[init+1]-CardPoints[init+2]>4 && CardPoints[init+2]-CardPoints[init+3]<4 && CardPoints[init+3]-CardPoints[init+4]>4)
    || (CardPoints[init]-CardPoints[init+1]>4 && CardPoints[init+1]-CardPoints[init+2]>4 && CardPoints[init+2]-CardPoints[init+3]>4 && CardPoints[init+3]-CardPoints[init+4]<4)){

      pair = true;
    }
    return pair;
  }

bool isTwoPair(int init, int *CardPoints, bool twoPair){

    if((CardPoints[init]-CardPoints[init+1]<4 && CardPoints[init+1]-CardPoints[init+2]>4 && CardPoints[init+2]-CardPoints[init+3]<4 && CardPoints[init+3]-CardPoints[init+4]>4)
    || (CardPoints[init]-CardPoints[init+1]<4 && CardPoints[init+1]-CardPoints[init+2]>4 && CardPoints[init+2]-CardPoints[init+3]>4 && CardPoints[init+3]-CardPoints[init+4]<4)
    || (CardPoints[init]-CardPoints[init+1]>4 && CardPoints[init+1]-CardPoints[init+2]<4 && CardPoints[init+2]-CardPoints[init+3]>4 && CardPoints[init+3]-CardPoints[init+4]<4)){

      twoPair = true;
    }
    return twoPair;
  }

bool isThreeOfAKind(int init, int *CardPoints, bool threeOfAKind){

    if((CardPoints[init]-CardPoints[init+1]<4 && CardPoints[init+1]-CardPoints[init+2]<4 && CardPoints[init+2]-CardPoints[init+3]>4 && CardPoints[init+3]-CardPoints[init+4]>4)
    || (CardPoints[init]-CardPoints[init+1]>4 && CardPoints[init+1]-CardPoints[init+2]<4 && CardPoints[init+2]-CardPoints[init+3]<4 &&  CardPoints[init+3]-CardPoints[init+4]>4)
    || (CardPoints[init]-CardPoints[init+1]>4 && CardPoints[init+1]-CardPoints[init+2]>4 && CardPoints[init+2]-CardPoints[init+3]<4 && CardPoints[init+3]-CardPoints[init+4]<4)){

      threeOfAKind  = true;
    }
    return threeOfAKind;
  }

bool isStraight(int init, int *CardPoints, bool straight , bool straightFlush){

    if ((CardPoints[init] > 140) && (CardPoints[init+1] > 50  && CardPoints[init+1] <=54)){
      CardPoints[init]=60; /* Caso seja o menor straight da-se o valor de 60 ao A e nao de 10 para nao ter de trocar as posicoes do vetor CardPoints,
      pois neste caso ele sera a carta menos valiosa */
    }

    if(CardPoints[init]-CardPoints[init+1]>=7 && CardPoints[init]-CardPoints[init+1]<=13 &&
      CardPoints[init+1]-CardPoints[init+2]>=7 && CardPoints[init+1]-CardPoints[init+2]<=13 &&
      CardPoints[init+2]-CardPoints[init+3]>=7 && CardPoints[init+2]-CardPoints[init+3]<=13 &&
      CardPoints[init+3]-CardPoints[init+4]>=7 && CardPoints[init+3]-CardPoints[init+4]<=13){
        straightFlush = isStraightFlush(init, CardPoints, straightFlush);
        if(!straightFlush){
          straight = true;
        }
      }
      return straight;
    }

bool isFlush(int init, int *CardPoints, bool flush){

      if((CardPoints[init]%10 == CardPoints[init+1]%10) &&  (CardPoints[init+1]%10 == CardPoints[init+2]%10) &&
      (CardPoints[init+2]%10 == CardPoints[init+3]%10) && (CardPoints[init+3]%10 == CardPoints[init+4]%10)){

        flush  = true;
      }
      return flush;
    }

bool isFullHouse(int init, int *CardPoints, bool fullHouse){

      if((CardPoints[init]-CardPoints[init+1]<4 && CardPoints[init+1]-CardPoints[init+2]<4 && CardPoints[init+2]-CardPoints[init+3]>4 && CardPoints[init+3]-CardPoints[init+4]<4)
      || (CardPoints[init]-CardPoints[init+1]<4 && CardPoints[init+1]-CardPoints[init+2]>4 && CardPoints[init+2]-CardPoints[init+3]<4 && CardPoints[init+3]-CardPoints[init+4]<4)){

        fullHouse= true;
      }
      return fullHouse;
    }

bool isFourOfAKind(int init, int *CardPoints, bool fourOfAKind){

      if((CardPoints[init]-CardPoints[init+1]==1 && CardPoints[init+1]-CardPoints[init+2]==1 && CardPoints[init+2]-CardPoints[init+3]==1)
      ||(CardPoints[init+1]-CardPoints[init+2]==1 && CardPoints[init+2]-CardPoints[init+3]==1 && CardPoints[init+3]-CardPoints[init+4]==1)){

        fourOfAKind = true;
      }
      return fourOfAKind;
    }

bool isStraightFlush(int init, int *CardPoints, bool straightFlush){

      if ((CardPoints[init] > 140) && (CardPoints[init+1] > 50  && CardPoints[init+1] <=54)){
        CardPoints[init] = 60 + (CardPoints[init]-140); // Faz o mesmo que no straight mas adiciona-se o valor do Suit, para analisar corretamente a mao
      }

      if(CardPoints[init]-CardPoints[init+1]==10 && CardPoints[init+1]-CardPoints[init+2]==10 && CardPoints[init+2]-CardPoints[init+3]==10 &&
        CardPoints[init+3]-CardPoints[init+4]==10){

          straightFlush = true;
        }
        return straightFlush;
      }

bool isRoyalFlush(int init, int *CardPoints, bool royalFlush, bool straightFlush){

        if(CardPoints[init] > 140 && CardPoints[init+1] > 130){
          straightFlush = isStraightFlush(init, CardPoints, straightFlush);
          if(straightFlush){
            royalFlush = true;
          }
        }
        return royalFlush;
      }

int handValue(int init, int *CardPoints){
        int hand = 0;
        bool royalFlush = false, straightFlush = false, fourOfAKind = false, fullHouse = false, flush = false;
        bool straight = false, threeOfAKind = false, twoPair = false, pair = false;

        royalFlush = isRoyalFlush(init, CardPoints, royalFlush, straightFlush);
        straightFlush = isStraightFlush(init, CardPoints, straightFlush);
        fourOfAKind = isFourOfAKind(init, CardPoints, fourOfAKind);
        fullHouse = isFullHouse(init, CardPoints, fullHouse);
        flush = isFlush(init, CardPoints, flush);
        straight = isStraight(init, CardPoints, straight, straightFlush);
        threeOfAKind = isThreeOfAKind(init, CardPoints, threeOfAKind);
        twoPair = isTwoPair(init, CardPoints, twoPair);
        pair = isPair(init, CardPoints, pair);


        if(royalFlush){
          hand = 10;
        }
        else if(straightFlush){
          hand = 9;
        }
        else if(fourOfAKind){
          hand = 8;
        }
        else if(fullHouse){
          hand = 7;
        }
        else if(flush){
          hand = 6;
        }
        else if(straight){
          hand = 5;
        }
        else if(threeOfAKind){
          hand = 4;
        }
        else if(twoPair){
          hand = 3;
        }
        else if(pair){
          hand = 2;
        }
        else{
          hand = 1;
        }
        return hand;
      }

void ordenateCards(int init, int nr_Cards) {

        char Cards_order[3];
        int aux = 0, aux2 = 0;

        for (int i = init; i < nr_Cards; i++){
          switch(Cards[i][0]){
            case '2':
            CardPoints[i] = 20;
            CardsRanks[i] = 1;
            break;
            case '3':
            CardPoints[i] = 30;
            CardsRanks[i] = 2;
            break;
            case '4':
            CardPoints[i] = 40;
            CardsRanks[i] = 3;
            break;
            case '5':
            CardPoints[i] = 50;
            CardsRanks[i] = 4;
            break;
            case'6':
            CardPoints[i] = 60;
            CardsRanks[i] = 5;
            break;
            case '7':
            CardPoints[i] = 70;
            CardsRanks[i] = 6;
            break;
            case '8':
            CardPoints[i] = 80;
            CardsRanks[i] = 7;
            break;
            case '9':
            CardPoints[i] = 90;
            CardsRanks[i] = 8;
            break;
            case 'T':
            CardPoints[i] = 100;
            CardsRanks[i] = 9;
            break;
            case 'J':
            CardPoints[i] = 110;
            CardsRanks[i] = 10;
            break;
            case 'Q':
            CardPoints[i] = 120;
            CardsRanks[i] = 11;
            break;
            case 'K':
            CardPoints[i] = 130;
            CardsRanks[i] = 12;
            break;
            case 'A':
            CardPoints[i] = 140;
            CardsRanks[i] = 13;
            break;
          }

          switch(Cards[i][1]){
            case 'P':
            CardPoints[i]+=1;
            break;
            case'O':
            CardPoints[i]+=2;
            break;
            case 'E':
            CardPoints[i]+=3;
            break;
            case'C':
            CardPoints[i]+=4;
            break;
          }
        }

        // Ordenar cartas por Rank(valor) e Suit(Ordem alfabetica)

        for (int i = init; i < nr_Cards; i++){
          for(int j = i + 1; j < nr_Cards; j++){
            if(CardPoints[i] < CardPoints[j]){
              strcpy(Cards_order, Cards[i]);
              strcpy(Cards[i], Cards[j]);
              strcpy(Cards[j], Cards_order);
              aux = CardPoints[i];
              CardPoints[i] = CardPoints[j];
              CardPoints[j] = aux;
            }
            if(CardsRanks[i] < CardsRanks[j]){
              aux2 = CardsRanks[i];
              CardsRanks[i] = CardsRanks[j];
              CardsRanks[j] = aux2;
            }
          }
        }
      }

int findBestHighCard(void){
        int winner = 0;

        for(int i = 0; i < 5; i++){
          if(CardsRanks[i] > CardsRanks[i+5]){
            winner = 1;
            break;
          }
          else if(CardsRanks[i] < CardsRanks[i+5]) {
            winner = 2;
            break;
          }
        }
        return winner;
      }

int findBestPair(void){
        int winner = 0;
        int firstPair = 0, secondPair = 0;

        for(int i=0; i<5;i++){
          if(CardsRanks[i] == CardsRanks[i+1]){
            firstPair = CardsRanks[i];
            break;
          }
        }
        for(int i=5; i<10;i++){
          if (CardsRanks[i] == CardsRanks[i+1]){
            secondPair = CardsRanks[i];
            break;
          }
        }

        if (firstPair  > secondPair){
          winner = 1;
        }
        else if (firstPair < secondPair){
          winner = 2;
        }
        else{
          winner = findBestHighCard();
        }

        return winner;
      }

int findBestTwoPair(void){
        int firstPair1 = 0, firstPair2 = 0, secondPair1 = 0, secondPair2 = 0;
        int winner = 0;

        for(int i=0; i < 5;i++){
          if (CardsRanks[i] == CardsRanks[i+1]){
            firstPair1 = CardsRanks[i];
            if (CardsRanks[i+2] == CardsRanks[i+3]){
              secondPair1 = CardsRanks[i+2];
            } else secondPair1 = CardsRanks[i+3];
            break;
          }
        }

        for(int i=5; i < 10;i++){
          if (CardsRanks[i] == CardsRanks[i+1]){
            firstPair2 = CardsRanks[i];
            if (CardsRanks[i+2] == CardsRanks[i+3]){
              secondPair2 = CardsRanks[i+2];
            } else secondPair2 = CardsRanks[i+3];
            break;
          }
        }

        if (firstPair1  > firstPair2){
          winner = 1;
        }
        else if (firstPair1 < firstPair2){
          winner = 2;
        }
        else{
          if (secondPair1 > secondPair2){
            winner = 1;
          }
          else if (secondPair1 < secondPair2){
            winner = 2;
          }
          else{
            winner = findBestHighCard();
          }
        }
        return winner;
}

int findBestThreeOfAKind(void){
        int firstTriplet = 0, secondTriplet = 0;
        int winner = 0;

        for(int i=0; i<5;i++){
          if(CardsRanks[i] == CardsRanks[i+1] && CardsRanks[i+1] == CardsRanks[i+2] ){
            firstTriplet = CardsRanks[i];
            break;
          }
        }
        for(int i=5; i<10;i++){
          if(CardsRanks[i] == CardsRanks[i+1] && CardsRanks[i+1] == CardsRanks[i+2] ){
            secondTriplet = CardsRanks[i];
            break;
          }
        }

        if (firstTriplet  > secondTriplet){
          winner = 1;
        }
        else if (firstTriplet < secondTriplet){
          winner = 2;
        }
        else{
          winner = findBestHighCard();
        }
        return winner;
}

int findBestFullHouse(void){
        int winner = 0;
        int fullHouseTriplet1 = 0, fullHousePair1 = 0, fullHouseTriplet2 = 0, fullHousePair2 = 0;

        for(int i = 0; i < 5; i++){
          if(CardsRanks[i] == CardsRanks[i+1] && CardsRanks[i+1] == CardsRanks[i+2]){
            fullHouseTriplet1 = CardsRanks[i];
            fullHousePair1 = CardsRanks[i+3];
          } else{fullHouseTriplet1 = CardsRanks[i+2];
            fullHousePair1 = CardsRanks[i];
          }  break;
        }
        for(int i = 5; i < 10; i++){
          if(CardsRanks[i] == CardsRanks[i+1] && CardsRanks[i+1] == CardsRanks[i+2]){
            fullHouseTriplet2 = CardsRanks[i];
            fullHousePair2 = CardsRanks[i+3];
          } else{fullHouseTriplet2 = CardsRanks[i+2];
            fullHousePair2 = CardsRanks[i];
          } break;
        }

        if (fullHouseTriplet1  > fullHouseTriplet2){
          winner = 1;
        }
        else if (fullHouseTriplet1 < fullHouseTriplet2){
          winner = 2;
        }
        else{
          if (fullHousePair1  > fullHousePair2){
            winner = 1;
          }
          else if (fullHousePair1 < fullHousePair2){
            winner = 2;
          }
        }

        return winner;
}

int findBestFourOfAKind(void){
        int winner = 0;
        int firstPoker = 0, secondPoker = 0;

        for(int i=0; i<5;i++){
          if(CardsRanks[i] == CardsRanks[i+1] && CardsRanks[i+1] == CardsRanks[i+2] && CardsRanks[i+2] == CardsRanks[i+3]){
            firstPoker = CardsRanks[i];
          } else{
            firstPoker = CardsRanks[i+1];
          } break;
        }
        for(int i=5; i<10;i++){
          if(CardsRanks[i] == CardsRanks[i+1] && CardsRanks[i+1] == CardsRanks[i+2] && CardsRanks[i+2] == CardsRanks[i+3] ){
            secondPoker = CardsRanks[i];
          } else{
            secondPoker = CardsRanks[i+1];
          } break;
        }

        if (firstPoker  > secondPoker){
          winner = 1;
        }
        else if (firstPoker < secondPoker){
          winner = 2;
        }
        else{
          winner = findBestHighCard();
        }
        return winner;
}

int clashResult(int hand1, int hand2){
        int winner = 0;

        if(hand1 > hand2){
          winner = 1;
        }
        else if(hand1 < hand2){
          winner = 2;
        }

        else {
          switch(hand1){
            case 1:
            winner = findBestHighCard();
            break;
            case 2:
            winner = findBestPair();
            break;
            case 3:
            winner = findBestTwoPair();
            break;
            case 4:
            winner = findBestThreeOfAKind();
            break;
            case 5:
            changePositions2(0);
            changePositions2(5);
            winner = findBestHighCard();
            break;
            case 6:
            winner = findBestHighCard();
            break;
            case 7:
            winner = findBestFullHouse();
            break;
            case 8:
            winner = findBestFourOfAKind();
            break;
            case 9:
            changePositions2(0);
            changePositions2(5);
            winner = findBestHighCard();
            break;
            case 10:
            winner = 0;
            break;
          }
        }
        return winner;
}

int bestCard(char card1[3], char card2[3]) {

        char letter[5] = {'A', 'K', 'Q', 'J', 'T'};

        if(card1[0] == card2[0] && card1[1] == card2[1]){ // aqui o naipe e um fator de desempate
          return 0;
        }else if(card1[0] == card2[0]){
          if(card1[1] < card2[1]) return 1;
          else if(card1[1] > card2[1]) return 2;
          else return 0;
        }else{
          if(card1[0] != 'A' && card1[0] != 'J' && card1[0] != 'K' && card1[0] != 'T' && card1[0] != 'Q' && card2[0] != 'A' && card2[0] != 'J' && card2[0] != 'K' && card2[0] != 'T' && card2[0] != 'Q') {
            if(card1[0] > card2[0]) return 1;
            else if(card1[0] < card2[0]) return 2;
            else return 0;
          }
          else if(card2[0] != 'A' && card2[0] != 'J' && card2[0] != 'K' && card2[0] != 'T' && card2[0] != 'Q'){
            return 1;
          }
          else if(card1[0] != 'A' && card1[0] != 'J' && card1[0] != 'K' && card1[0] != 'T' && card1[0] != 'Q') {
            return 2;
          }
          else {
            for(int i = 0; i < 5; i++) {
              if(card1[0] == letter[i] && card2[0] != letter[i]) return 1;
              else if(card1[0] != letter[i] && card2[0] == letter[i]) return 2;
            }
          }
        }

        return 0;
}

int bestHandPossible(int init, int nr_Cards, char *argv[]){

        int max_hand = 0, winner = 0;

        for (int i = init; i < nr_Cards - 4; i++){
          for (int j = i + 1; j < nr_Cards - 3; j++){
            for (int k = j + 1; k < nr_Cards - 2; k++){
              for (int p = k + 1; p < nr_Cards - 1; p++){
                for (int n = p + 1; n < nr_Cards; n++){
                  strcpy(Cards[0], Cards2[i]); // Em Cards2 percorrem-se todas as possibilidades de maos
                  strcpy(Cards[1], Cards2[j]); // Coloca-se Cards2 em Cards, pois Cards e' o vetor utilizado nas funcoes ordenateCards e handValue
                  strcpy(Cards[2], Cards2[k]);
                  strcpy(Cards[3], Cards2[p]);
                  strcpy(Cards[4], Cards2[n]);

                  ordenateCards(0, nr_Cards-2);
                  int hand = handValue(0, CardPoints);

                  if(hand == 5 || hand == 9){
                    changePositions2(0);
                  }

                  if (hand > max_hand) {
                    max_hand = hand;
                    for (int i=0; i < nr_Cards-2; i++){
                      strcpy(PossibleHand1[i], Cards[i]);
                    }
                  }
                  else if(hand == max_hand){
                    for (int i=0; i < nr_Cards-2; i++){
                      strcpy(PossibleHand2[i], Cards[i]);
                    }

                    if(hand == 5 || hand == 9){
                      changePositions1();
                    }

                    for(int i = 0; i < nr_Cards - 2 ; i++){
                      winner = bestCard(PossibleHand1[i], PossibleHand2[i]);
                      if(winner == 1){
                        break;
                      }
                      if(winner == 2){
                        for (int j=0; j < nr_Cards-2; j++){
                          strcpy(PossibleHand1[j], PossibleHand2[j]);
                        }
                        break;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        for (int j=0; j < nr_Cards-2; j++){
          strcpy(PossibleHand3[j], PossibleHand1[j]);
        }

        return max_hand;
}

void printCards1(int hand, char *argv[]){

        char aux[3];

        if (hand == 5 || hand == 9) {
          if(PossibleHand3[0][0] == 'A' && PossibleHand3[1][0] == '5' && PossibleHand3[2][0] == '4' && PossibleHand3[3][0] == '3' && PossibleHand3[4][0] == '2'){
            for (int i = 0; i < 5; i++){
              for(int j = i + 1; j < 5; j++){
                strcpy(aux, PossibleHand3[i]);
                strcpy(PossibleHand3[i], PossibleHand3[j]);
                strcpy(PossibleHand3[j], aux);
              }
            }
            for (int i = 0; i < 4; i++){
              for(int j = i + 1; j < 4; j++){
                strcpy(aux, PossibleHand3[i]);
                strcpy(PossibleHand3[i], PossibleHand3[j]);
                strcpy(PossibleHand3[j], aux);
              }
            }
          }
        }

        if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
          for (int i = 0; i < 5; i++) {
            fprintf(Write, "%s ", PossibleHand3[i]);
            strcpy(Temp[i], PossibleHand3[i]);
          }
        }else{
          for (int i = 0; i < 5; i++){
            printf("%s ", PossibleHand3[i]);
            strcpy(Temp[i], PossibleHand3[i]); //Temp utiliza-se para poder fazer o clashResult entre as maos dos jogadores no caso de haver 9 cartas
          }
        }
      }

void printCards2(int hand, char *argv[]){
        char aux[3];

        if (hand == 5 || hand == 9) {
          if(PossibleHand3[0][0] == 'A' && PossibleHand3[1][0] == '5' && PossibleHand3[2][0] == '4' && PossibleHand3[3][0] == '3' && PossibleHand3[4][0] == '2'){
            for (int i = 0; i < 5; i++){
              for(int j = i + 1; j < 5; j++){
                strcpy(aux, PossibleHand3[i]);
                strcpy(PossibleHand3[i], PossibleHand3[j]);
                strcpy(PossibleHand3[j], aux);
              }
            }
            for (int i = 0; i < 4; i++){
              for(int j = i + 1; j < 4; j++){
                strcpy(aux, PossibleHand3[i]);
                strcpy(PossibleHand3[i], PossibleHand3[j]);
                strcpy(PossibleHand3[j], aux);
              }
            }
          }
        }

        if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){

          for (int i = 0; i < 5; i++) {
            fprintf(Write, "%s ", PossibleHand3[i]);
            strcpy(Temp[i+5], PossibleHand3[i]);
          }
        }else{
          for (int i = 0; i < 5; i++){
            printf("%s ", PossibleHand3[i]);
            strcpy(Temp[i], PossibleHand3[i]); //Temp utiliza-se para poder fazer o clashResult entre as maos dos jogadores no caso de haver 9 cartas
          }
        }
}

int validateCards(int init, int nr_Cards){

        bool ilegalRank, ilegalSuit;

        for (int i = init; i < nr_Cards; i++) {
          if(strlen(AnallyseHand[i])!= 2){
            return -1;
          }
        }

        for ( int k = init; k < nr_Cards; k++){
          ilegalRank = false;

          for (int p = 0; p < MAX_RANKS; p++){
            if(AnallyseHand[k][0] == ranks[p]){
              ilegalRank = true;
            }
          }
          if(ilegalRank == false){
            return -1;
          }

          ilegalSuit = false;

          for (int p = 0; p < MAX_SUITS; p++){
            if(AnallyseHand[k][1] == suits[p]){
              ilegalSuit = true;
            }
          }
          if(ilegalSuit == false){
            return -1;
          }
        }
        return 0;
      }

int checkDuplicates (int init, int nr_Cards){

        for (int i = init; i < nr_Cards - 1; i++) {
          for (int j = i + 1; j < nr_Cards; j++) {
            if (!strcmp(AnallyseHand[i],AnallyseHand[j])) {
              return -1;
            }
          }
        }
        return 0;
      }

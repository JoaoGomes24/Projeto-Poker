/*
=====================================================================================================================
Nome do programa: Pokeristars
Projeto para a UC de Programacao do curso de MEEC do IST 2019/2020 1 Ano 2 Semestre

Este programa tem como objetivo simular um jogo de Poker

Ficheiros:
  (1)pokeristars.c: Programa principal, onde se situa a funcao main
  (2)CommandLineMode.c: Analisa as cartas pretendidas, modo -c
  (3)DeckMode.c: Processa diversos baralhos, modo -di e -dx
  (4)ShufflingMode.c: Baralha as cartas consoante os digitos introduzidos antes dos respetivos baralhos, modo -s1

Autores: Joao Gomes - 96248
Tiago Franco - 96333                                                                             Data: 22/05/2020
====================================================================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "pokeristars.h"

char ranks[MAX_RANKS] = {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'};
char suits[MAX_SUITS] = {'C', 'E', 'O', 'P'};

int main(int argc, char *argv[]) {

  char WantedExtension[] = "deck", WantedExtension2[] = "shuffle", ch = '.', *ReadExtension;

  if (argc > 2){
    TestMode = &argv[1][1];  //Variavel que guarda o modo pretendido(c,d,s)

    if(strcmp(argv[1], "-c") == 0){
      int nr_Cards = argc-2;
      for (int i = 0; i < nr_Cards; i++) {
        strcpy(AnallyseHand[i], argv[i+2]);
      }
      runCommandLine(nr_Cards, argv);
    }else if ((argv[1][0] == '-' && argv[1][1] == 'd') && (strlen(argv[1]) == 3)){
      if(argc > 5){
        printf("-1\n");
        exit(0);
      }
      if((argv[4] == NULL && strcmp(argv[3], "-o") == 0)){  //Verificamos se existe um ficheiro de escrita quando se coloca a opcao de escrever a saida em ficheiros "-o"
        printf("-1\n");
        exit(0);
      }
      if((ReadExtension = strrchr(argv[2], ch)) == NULL){  //ch serve para verificar a extensao do ficheiro
        if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
          fprintf(Write, "-1\n");
        }else{
          printf("-1\n");
        }
        exit(0);
      }
      if(strcmp((ReadExtension+1), WantedExtension) != 0){ //Verifica-se se a extensao do ficheiro de leitura e a correta, apenas a partir do ponto, dai o "+1" no ReadExtension
        if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
          fprintf(Write, "-1\n");
        }else{
          printf("-1\n");
        }
        exit(0);
      }else {
        runDeckMode(argv);
      }
    }else if(strcmp(argv[1], "-s1") == 0){
      if(argc > 5){
        printf("-1\n");
        exit(0);
      }
      if((argv[4] == NULL && strcmp(argv[3], "-o") == 0)){
        printf("-1\n");
        exit(0);
      }
      if((ReadExtension = strrchr(argv[2], ch)) == NULL){
        if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
          fprintf(Write, "-1\n");
        }else{
          printf("-1\n");
        }
        exit(0);
      }
      if(strcmp((ReadExtension+1), WantedExtension2) != 0){
        if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
          fprintf(Write, "-1\n");
        }else{
          printf("-1\n");
        }
        exit(0);
      }else {
        runShuffleMode(argv);
      }
    }else{
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "-1\n");
      }else{
        printf("-1\n");
      }
    }
  }else{
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "-1\n");
    }else{
      printf("-1\n");
    }
  }

  return 0;
}

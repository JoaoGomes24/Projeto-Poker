#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "pokeristars.h"

void runDeckMode(char *argv[]){

  char card[4], CardFormat[4], WantedExtension[] = "deck", ch = '.', *ReadExtension;
  int rest = 0, TotalComb = 0, nr_Cards = 0, read_cards = 0, NeedEnter = 0, out = 1;
  FILE *Decks;

  if((Decks = fopen(argv[2], "r")) == NULL){
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "-1\n");
    }else{
      printf("-1\n");
    }
    exit(0);
  }

  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
    if((ReadExtension = strrchr(argv[4], ch)) == NULL){
      fclose(Decks);
      printf("-1\n");
      exit(0);
    }
    if(strcmp((ReadExtension+1), WantedExtension) == 0 ){ //Caso a extensao do ficheiro de escrita seja a mesma que o de leitura, da erro
      printf("-1\n");
      exit(0);
    }
    Write = fopen(argv[4], "w");
  }

  sprintf(CardFormat, "%%%ds", 3);  // Formato pretendido para cada carta

  switch (argv[1][2]){
    case'1':
    nr_Cards = 5;
    break;
    case'2':
    nr_Cards = 7;
    break;
    case '3':
    nr_Cards = 9;
    break;
    case '4':
    nr_Cards = 10;
    break;
    case 'x':
    runExtraDeckMode(argv, Decks);
    return;
    default:
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "-1\n");
    }else{
      printf("-1\n");
    }
    exit(0);
  }

  rest = MAX_CARDS % nr_Cards; // numero de cartas que nao formam um baralho completo
  read_cards = MAX_CARDS-rest;
  TotalComb = read_cards / nr_Cards;

  while(1){   //Ciclo infinito, ate acabar de ler o ficheiro
    for(int i = 0; i < TotalComb; i++){
      for(int j = 0; j < nr_Cards; j++){
        if((fscanf(Decks, CardFormat, card)) == 1){ // le uma carta de cada vez
          strcpy(AnallyseHand[j], card);
        }else{
          fclose(Decks);  //Caso nao leia nenhuma string nova, da-se o fim do ficheiro, fechando-o
          out = 0;        //Coloca-se out a 0, para saber que o ficheiro acabou
          break;
        }
      }
      if(out == 0){
        break;
      }

      runCommandLine(nr_Cards, argv);
      NeedEnter++;  //Faz a contagem de combinacoes feitas, para dar enter entre cada baralho

      if(nr_Cards == 10 || nr_Cards == 9){
        if(NeedEnter%5 == 0){
          if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
            fprintf(Write, "\n");
          }else{
            printf("\n");
          }
        }
      }else if(nr_Cards == 7){
        if(NeedEnter%7 == 0){
          if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
            fprintf(Write, "\n");
          }else{
            printf("\n");
          }
        }
      }else if(nr_Cards == 5){
        if(NeedEnter%10 == 0){
          if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
            fprintf(Write, "\n");
          }else{
            printf("\n");
          }
        }
      }
    }

    if(out == 0){
      break;
    }
    for (int k = 0; k < rest; k++) {
      if((fscanf(Decks, CardFormat, card)) == 1){ // le as restantes cartas
        strcpy(AnallyseHand[k], card);
      }
    }
  }

  printHandOdds(argv);

  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
    fprintf(Write, "\n");
  }else{
    printf("\n");
  }

  if(nr_Cards == 9 || nr_Cards == 10){
    printWinnerOdds(argv);
  }

  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
    fclose(Write);  //Fecha o ficheiro de escrita
  }
}

void checkHand(int Hand){

  switch (Hand) {   //Verifica o tipo de mao, contando as vezes que cada uma aparece
    case 1:
    Hands[1]++;
    break;
    case 2:
    Hands[2]++;
    break;
    case 3:
    Hands[3]++;
    break;
    case 4:
    Hands[4]++;
    break;
    case 5:
    Hands[5]++;
    break;
    case 6:
    Hands[6]++;
    break;
    case 7:
    Hands[7]++;
    break;
    case 8:
    Hands[8]++;
    break;
    case 9:
    Hands[9]++;
    break;
    case 10:
    Hands[10]++;
    break;
    case -1:
    Hands[0]++;
    break;
  }
  Total_Hands++;
}

void printHandOdds(char *argv[]){

  if(argv[1][2] != 'x'){      //Caso o modo de funcionamento seja o -dx, nao existem maos ilegais, logo nao entra para as estatisticas
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "-1 %2.2E\n", Hands[0]/Total_Hands);
    }else{
      printf("-1 %2.2E\n", Hands[0]/Total_Hands);
    }
  }
  for (int i = 1; i < 11; i++) {
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "%d %2.2E\n", i, Hands[i]/Total_Hands);
    }else{
      printf("%d %2.2E\n", i, Hands[i]/Total_Hands);
    }
  }
}

void checkWinner(int Winner){

  switch (Winner){  //Verifica o tipo de vencedor, contando as vezes que aparece
    case 1:
    Winners[1]++;
    break;
    case 2:
    Winners[2]++;
    break;
    case 0:
    Winners[0]++;
    break;
  }
  Total_Winners++;
}

void printWinnerOdds(char *argv[]){

  for (int i = 0; i < 3; i++) {
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "%d %d\n", i, Winners[i]);
    }else{
      printf("%d %d\n", i, Winners[i]);
    }
  }
}

void runExtraDeckMode(char *argv[], FILE *Decks){

  char Players[16][3], Table[5][3], card[3], CardFormat[4];
  int k = 0, out = 1, Print = 0;
  Index = 0;
  NumPlayers = 8;                    //Inicializa o primeiro numero de jogadores
  sprintf(CardFormat, "%%%ds", 3);  // Formato pretendido para cada carta

  while(1){
    for(int i = 0; i < NumPlayers; i++){
      for(int j = 0; j < 2; j++){
        if((fscanf(Decks, CardFormat, card)) == 1){       // le uma carta de cada vez
          strcpy(Players[k++], card);               //Atribui 2 cartas a cada jogador que esteja em jogo
          if(k == NumPlayers*2){                    //No fim de atribuir a todos, coloca as cartas da mesa
            for (int m = 0; m < 5; m++){
              if((fscanf(Decks, CardFormat, card)) == 1){
                strcpy(Table[m], card);
              }
            }
          }
        }else{
          fclose(Decks);      //Mesmo raciocinio do modo -di
          out = 0;
          break;
        }
      }
      if(out == 0){
        break;
      }
    }

    if(out == 0){
      break;
    }

    k = 0;
    for (int i = 0; i < NumPlayers; i++) {
      for (int j = 0; j < 2; j++) {
        strcpy(AnallyseHand[j], Players[k++]); //Coloca as maos um jogador de cada vez no vetor onde serao analisadas
      }
      for (int m = 0; m < 5; m++) {
        strcpy(AnallyseHand[m+2], Table[m]); //Coloca-se as cartas da mesa no mesmo vetor onde estao as do jogador
      }
      while(Index < 8){
        if(InGame[Index] == -1){      //Verifica-se os jogadores inativos
          Index++;
        }else{
          PlayerPosition = Index + 1; //Inicializa-se a posicao do primeiro jogador (ordem crescente) a estar ativo
          Index++;
          break;
        }
      }
      runCommandLine(7, argv);
    }

    for (int n = 0; n < 8; n++){
      if(DidFold[n] == 1){ //Verifica-se quantos jogadores fizeram fold
        Print++;
      }
    }
    if(Print != NumPlayers){ //Caso os numero de folds seja igual ao numero de jogadores em jogo, nao se imprime estatisticas, nem dados
      printWinnerData(argv);
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "\n");
      }else{
        printf("\n");
      }
    }

    for (int i = 0; i < MAX_CARDS-((NumPlayers*2)+5); i++){ //Le-se as restantes cartas do baralho
      if((fscanf(Decks, CardFormat, card)) == 1){
        strcpy(AnallyseHand[0], card);
      }
    }
    for (int n = 0; n < 8; n++){
      if(InGame[n] == -1){ //Caso o jogador tenha estado inativo na jogada anterior, entra em jogo na proxima
        InGame[n] = 0;
        Plays[n] = 0;
      }
    }

    NumPlayers = 8;
    for (int i = 0; i < 8; i++){
      if(Plays[i] == 2){ //Verifica-se quantos jogadores vao a jogo na proxima ronda
        InGame[i] = -1;
        NumPlayers--;
      }
    }

    HigherHand = 0; //Inicializacoes para a proxima ronda
    Positions = 0;
    Index = 0;
    Print = 0;
    k = 0;

    if(NumPlayers == 0){ //Caso nao haja jogadores em jogo, passa-se um baralho a frente
      for (int i = 0; i < MAX_CARDS; i++) {
        if((fscanf(Decks, CardFormat, card)) == 1){
          strcpy(AnallyseHand[0], card);
        }
      }
    }
  }

  printHandOdds(argv);
  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
    fprintf(Write, "\n");
  }else{
    printf("\n");
  }

  printWinnerOddsExtraMode(argv);

  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
    fclose(Write);
  }
}

void bestExtraMode(int hand, char *argv[]){
  int winner = 0;

  if(hand >= HigherHand){
    if(hand > HigherHand){
      HigherHand = hand;  //Caso entre na condicao, define-se a maior mao ate ao momento
      HighestHand = hand; //Definindo-se tambem a maior mao de todas
      Positions = 0;
      for (int i = 0; i < 5; i++){
        strcpy(PossiblePrint[i], PossibleHand3[i]);
      }
    }

    for(int j = 0; j < 5; j++){             //Caso as maos sejam iguais determina-se o vencedor
      strcpy(Cards[j], PossiblePrint[j]);
      strcpy(Cards[j+5], PossibleHand3[j]);
    }

    ordenateCards(0, 5);
    ordenateCards(5, 10);
    winner = clashResult(HigherHand, hand);

    if(winner == 2){
      for (int j = 0; j < 5; j++){
        strcpy(PossiblePrint[j], PossibleHand3[j]);
        Positions = 0;
        PositionWinner[Positions++] = PlayerPosition;
        Number_of_Winners = Positions;
      }
    }

    if(winner == 0){
      PositionWinner[Positions++] = PlayerPosition;
      Number_of_Winners = Positions;
    }
  }
}

void printWinnerData(char *argv[]){

  double Points;

  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
    fprintf(Write, "W ");
  }else{
    printf("W ");
  }

  for (int i = 0; i < 5; i++) {
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){ //Imprime-se a mao vencedora
      fprintf(Write, "%s ", PossiblePrint[i]);
    }else{
      printf("%s ", PossiblePrint[i]);
    }
  }

  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){ //Imprime-se o numero da mao do vencedor
    fprintf(Write, "%d", HighestHand);
  }else{
    printf("%d", HighestHand);
  }

  checkHand(HighestHand);

  for (int k = 0; k < Number_of_Winners ; k++){
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, " %d", PositionWinner[k]);  //Imprime-se os jogadores que venceram a ronda
    }else{
      printf(" %d", PositionWinner[k]);
    }
    if(Number_of_Winners == 1){   //Calcula-se quantos pontos se deve atribuir a cada jogador
      Points = 1;
      checkWinnerExtraMode(PositionWinner[k], Points);
    }else{
      Points = (double) 1 / (double) Number_of_Winners;
      checkWinnerExtraMode(PositionWinner[k], Points);
    }
  }

  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
    fprintf(Write, "\n");
  }else{
    printf("\n");
  }
}

void checkWinnerExtraMode(int Winner, double Points){

  switch (Winner){
    case 1:
    Winners2[0]+=Points;
    break;
    case 2:
    Winners2[1]+=Points;
    break;
    case 3:
    Winners2[2]+=Points;
    break;
    case 4:
    Winners2[3]+=Points;
    break;
    case 5:
    Winners2[4]+=Points;
    break;
    case 6:
    Winners2[5]+=Points;
    break;
    case 7:
    Winners2[6]+=Points;
    break;
    case 8:
    Winners2[7]+=Points;
    break;
  }
  Total_Winners++;
}

void printWinnerOddsExtraMode(char *argv[]){

  double Player1 = Winners2[0], Player2 = Winners2[1], Player3 = Winners2[2], Player4 = Winners2[3]; //Inicializa-se cada jogador, com a sua estatistica respetiva
  double Player5 = Winners2[4], Player6 = Winners2[5], Player7 = Winners2[6], Player8 = Winners2[7];
  double Aux = 0;

  for (int i = 0; i < 8; i++){
    for(int j = i + 1; j < 8; j++){
      if(Winners2[i] < Winners2[j]){
        Aux = Winners2[i];
        Winners2[i] = Winners2[j];
        Winners2[j] = Aux;
      }
    }
  }

  for (int i = 0; i < 8; i++){
    if (Winners2[i] == Player1){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "1 %.2f\n", Winners2[i]);
      }else{
        printf("1 %.2f\n", Winners2[i]);
      }
      Player1 = -1;   //Caso entre na condicao, coloca-se o jogador com o numero "-1", significando que a sua estatistica ja foi impressa
    }else if (Winners2[i] ==  Player2){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "2 %.2f\n", Winners2[i]);
      }else{
        printf("2 %.2f\n", Winners2[i]);
      }
      Player2 = -1;
    }else if (Winners2[i] == Player3){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "3 %.2f\n", Winners2[i]);
      }else{
        printf("3 %.2f\n", Winners2[i]);
      }
      Player3 = -1;
    }else if (Winners2[i] == Player4){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "4 %.2f\n", Winners2[i]);
      }else{
        printf("4 %.2f\n", Winners2[i]);
      }
      Player4 = -1;
    }else if (Winners2[i] == Player5){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "5 %.2f\n", Winners2[i]);
      }else{
        printf("5 %.2f\n", Winners2[i]);
      }
      Player5 = -1;
    }else if (Winners2[i] == Player6){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "6 %.2f\n", Winners2[i]);
      }else{
        printf("6 %.2f\n", Winners2[i]);
      }
      Player6 = -1;
    }else if (Winners2[i] == Player7){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "7 %.2f\n", Winners2[i]);
      }else{
        printf("7 %.2f\n", Winners2[i]);
      }
      Player7 = -1;
    }else if (Winners2[i] == Player8){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "8 %.2f\n", Winners2[i]);
      }else{
        printf("8 %.2f\n", Winners2[i]);
      }
      Player8 = -1;
    }
  }
}

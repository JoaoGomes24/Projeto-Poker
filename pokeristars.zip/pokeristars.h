#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#ifndef POKERISTARS_INCLUDED
#define POKERISTARS_INCLUDED

#define MAX_CARDS 52
#define MAX_RANKS 13
#define MAX_SUITS 4

char Cards[10][3], Cards2[9][3], Temp[10][3], Seq[3];
char PossibleHand1[5][3], PossibleHand2[5][3], PossibleHand3[5][3];
char AnallyseHand[10][3], *TestMode, PossiblePrint[5][3];

FILE *Write;

int nr_Cards, CardPoints[10], CardsRanks[10], Total_Winners, Total_Hands, Winners[3];
int NumPlayers, PlayerPosition, PositionWinner[8], HighestHand, Number_of_Winners;
int Fold[8], DidFold[8], Plays[8], InGame[8], HigherHand, Positions, Index;

double Hands[11], Winners2[8];

typedef struct DeckData{
  char card[3];
  struct DeckData *next;
} DeckData;

typedef struct ShuffleOp{
  char SeqShuffle[2];
  struct ShuffleOp *next;
} ShuffleOp;

void runCommandLine(int, char **);
void runDeckMode(char **);
void checkHand(int);
void printHandOdds(char **);
void checkWinner(int);
void printWinnerOdds(char **);
void runShuffleMode(char **);
ShuffleOp *criaListaSeq(FILE *, char **);
ShuffleOp *endOfListSeq(ShuffleOp *, ShuffleOp *);
DeckData *criaListaDeck(FILE *, char **);
DeckData *endOfListaDeck(DeckData *, DeckData *);
DeckData *shuffleLists1(DeckData *);
DeckData *shuffleLists2(DeckData *);
DeckData *shuffleLists3(DeckData *);
void printLista(DeckData *, char **);
void freeList(DeckData *);
void runExtraDeckMode(char **, FILE *);
void bestExtraMode(int, char **);
void printWinnerData(char **);
void checkWinnerExtraMode(int, double);
void printWinnerOddsExtraMode(char **);
void inicializeCards5and10(int);
void inicializeCards7(int);
void inicializeFirstCards9(int);
void inicializeSecCards9(int);
void changePositions1(void);
void changePositions2(int);
bool isPair(int, int *, bool);
bool isTwoPair(int, int *, bool);
bool isThreeOfAKind(int, int *, bool);
bool isStraight(int, int *, bool, bool);
bool isFlush(int, int *, bool);
bool isFullHouse(int, int *, bool);
bool isFourOfAKind(int, int *, bool);
bool isStraightFlush(int, int *, bool);
bool isRoyalFlush(int, int *, bool, bool);
int  handValue(int, int *);
void ordenateCards(int, int);
int  findBestHighCard(void);
int  findBestPair();
int  findBestTwoPair();
int  findBestThreeOfAKindvoid();
int  findBestFullHouse();
int  findBestFourOfAKind();
int  clashResult(int, int);
int  bestCard(char *, char *);
int  bestHandPossible(int, int, char **);
void printCards1(int, char **);
void printCards2(int, char **);
int  validateCards(int, int);
int  checkDuplicates (int, int);

#endif // POKERISTARS_INCLUDED

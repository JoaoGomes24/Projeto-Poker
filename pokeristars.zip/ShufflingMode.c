#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "pokeristars.h"

void runShuffleMode(char *argv[]){

  DeckData *ListHeadDeck = NULL, *NewCard;
  ShuffleOp *ListHeadSeq = NULL, *NewSeq, *Aux;

  char SeqFormat[4], WantedExtension[] = "shuffle", ch = '.', *ReadExtension;
  int Seq_Int = 0;
  FILE *Shuffle;

  if((Shuffle = fopen(argv[2], "r")) == NULL){
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "-1\n");
    }else{
      printf("-1\n");
    }
    exit(0);
  }
  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
    if((ReadExtension = strrchr(argv[4], ch)) == NULL){
      printf("-1\n");
      fclose(Shuffle);
      exit(0);
    }
    if(strcmp((ReadExtension+1), WantedExtension) == 0 ){
      printf("-1\n");
      exit(0);
    }
    Write = fopen(argv[4], "w");
  }

  sprintf(SeqFormat, "%%%dd", 1);  // Formato pretendido para os digitos do modo de shuffle

  while (1){
    while (1){
      if((fscanf(Shuffle, "%s", Seq)) == 1){ //Le-se primeiro o digito para nao se colocar cartas na lista dos digitos
        if((strlen(Seq)) == 2){
          fseek(Shuffle, -2, SEEK_CUR); //Caso leia uma carta em vez de um digito, recua duas posicoes,
          break;
        }
        NewSeq = criaListaSeq(Shuffle, argv);   //Cria lista para os digitos (modo como ira baralhar)
        ListHeadSeq = endOfListSeq(ListHeadSeq, NewSeq); //Coloca-se os digitos na lista da forma como estao escritos no ficheiro
      }
    }
    for (int k = 0; k < MAX_CARDS; k++) { // cria uma lista com todo o deck
      NewCard = criaListaDeck(Shuffle, argv);
      ListHeadDeck = endOfListaDeck(ListHeadDeck, NewCard);
    }

    while(ListHeadSeq != NULL){ // baralha a lista dependendo do modo
      Aux = ListHeadSeq;
      if((strcmp(ListHeadSeq -> SeqShuffle, "1")) == 0){
        ListHeadDeck = shuffleLists1(ListHeadDeck);
      }
      else if((strcmp(ListHeadSeq -> SeqShuffle, "2")) == 0){
        ListHeadDeck = shuffleLists2(ListHeadDeck);
        ListHeadDeck = shuffleLists1(ListHeadDeck);
      }
      else if((strcmp(ListHeadSeq -> SeqShuffle, "3")) == 0){
        ListHeadDeck = shuffleLists3(ListHeadDeck);
      }
      else{
        if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
          fprintf(Write, "-1\n");
        }else{
          printf("-1\n");
        }
        exit(0);
      }
      ListHeadSeq = ListHeadSeq -> next; //Remove-se o elemento lido da lista
      free(Aux);
    }

    printLista(ListHeadDeck, argv);
    freeList(ListHeadDeck);

    if((fscanf(Shuffle, SeqFormat, &Seq_Int)) != 1) {
      fclose(Shuffle);
      break;
    }else{               // caso haja mais baralhos faz-se as inicializacoes
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "\n");
      }else{
        printf("\n");
      }
      ListHeadDeck = NULL;
      ListHeadSeq = NULL;
      fseek(Shuffle, -1, SEEK_CUR); //Anda-se uma posicao para tras, pois leu-se o primeiro digito (forma como se pretende baralhar) do baralho seguinte
    }
  }
  if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
    fclose(Write);
  }
}

ShuffleOp *criaListaSeq(FILE *Shuffle, char *argv[]){

  ShuffleOp *FSeq;

  if((FSeq = (ShuffleOp*)calloc(1, sizeof(ShuffleOp))) == NULL){
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "-1\n");
    }else{
      printf("-1\n");
    }
    exit(0);
  }
  strcpy(FSeq -> SeqShuffle, Seq);
  FSeq -> next = NULL;

  return FSeq;
}

ShuffleOp *endOfListSeq(ShuffleOp *ListHead, ShuffleOp *NewSeq){

  ShuffleOp *AuxH, *AuxT;

  if (ListHead == NULL) {
    ListHead = NewSeq;
  }else {
    AuxH = ListHead;
    AuxT = ListHead -> next;
    while (AuxT != NULL) {
      AuxH = AuxT;
      AuxT = AuxT -> next;
    }
    AuxH -> next = NewSeq;
  }
  return ListHead;
}

DeckData *criaListaDeck(FILE *Shuffle, char *argv[]){

  char CardFormat[4];
  DeckData *FCard;

  sprintf(CardFormat, "%%%ds", 3);  // Formato pretendido para cada carta

  if((FCard = (DeckData*)calloc(1, sizeof(DeckData))) == NULL){
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "-1\n");
    }else{
      printf("-1\n");
    }
    exit(0);
  }
  if((fscanf(Shuffle, CardFormat, FCard -> card)) == 1){
    FCard -> next = NULL;
  }

  return FCard;
}

DeckData *endOfListaDeck(DeckData *ListHead, DeckData *NewCard){

  DeckData *AuxH, *AuxT;

  if (ListHead == NULL) {
    ListHead = NewCard;
  } else {
    AuxH = ListHead;
    AuxT = ListHead -> next;
    while (AuxT != NULL) {
      AuxH = AuxT;
      AuxT = AuxT -> next;
    }
    AuxH -> next = NewCard;
  }
  return ListHead;
}

DeckData *shuffleLists1(DeckData *ListHead){

  DeckData *AuxH1, *AuxT1, *AuxH2, *AuxT2;
  int i = 0;

  for (int j = 0; j < (MAX_CARDS/2)-1; j++){
    AuxH1 = ListHead;
    AuxT1 = ListHead -> next;
    AuxH2 = ListHead;
    AuxT2 = ListHead -> next;
    while (i < (MAX_CARDS/2)-1 + j){
      AuxH2 = AuxT2;      //Coloca-se a variavel auxiliar a apontar para o meio do baralho
      AuxT2 = AuxT2 -> next;
      i++;
    }
    i = 0;  //Inicializa-se sempre o i no fim dos ciclos, para se fazer um ciclo a comecar no 0
    while (i < 2*j){   //Dado que se coloca, as cartas do meio alternadas com as do inicio, temos de andar 2 posicoes, para a lista ficar a apontar para o sitio correto
      AuxH1 = AuxT1;
      AuxT1 = AuxT1 -> next;
      i++;
    }
    i = 0;
    AuxH2 -> next = AuxT2 -> next;  //Manuseia-se a lista para que cada carta passe a apontar para a que pretendemos (primeira->meio->segunda->segunda do meio....)
    AuxH1 -> next = AuxT2;
    AuxT2 -> next = AuxT1;
  }
  return ListHead;
}

DeckData *shuffleLists2(DeckData *ListHead){

  DeckData *AuxH1, *AuxT1, *AuxH2, *AuxT2;
  int i = 0;

  for (int j = 0; j < (MAX_CARDS/2)-1; j++) {
    AuxH1 = ListHead;
    AuxT1 = ListHead -> next;
    AuxH2 = ListHead;
    AuxT2 = ListHead -> next;

    while (i < MAX_CARDS - 2){
      AuxH1 = AuxT1;        //Coloca-se a variavel auxiliar a apontar para a penultima carta do baralho
      AuxT1 = AuxT1 -> next;
      i++;
    }
    i = 0;
    while (i < (MAX_CARDS/2)-1 + j){ //Coloca-se a variavel auxiliar a apontar para o meio do baralho
      AuxH2 = AuxT2;
      AuxT2 = AuxT2 -> next;
      i++;
    }
    i = 0;

    AuxH1 -> next = AuxT1 -> next;  //Manuseia-se a lista de forma a trocar a ordem das cartas da segunda metade, ate estas ficarem, com a ultima no meio do baralho, a penultima da posicao seguinte...
    AuxH2 -> next = AuxT1;          //Serve para podermos baralhar da mesma forma que fazemos para o digito 1
    AuxT1 -> next = AuxT2;
  }
  return ListHead;
}

DeckData *shuffleLists3(DeckData *ListHead){

  DeckData *AuxH, *AuxT;
  int i = 0;

  for (int j = 0; j < (MAX_CARDS/2); j++){ //Coloca-se a variavel auxiliar a apontar para o meio do baralho
    AuxH = ListHead;
    AuxT = ListHead -> next;
    while (i < MAX_CARDS-2){   //Coloca-se a variavel auxiliar a apontar para a penultima carta do baralho
      AuxH = AuxT;
      AuxT = AuxT -> next;
      i++;
    }
    i = 0;
    AuxH -> next = AuxT -> next; //Manuseia-se a lista de forma a que a que se troque a metade de baixo com a de cima
    AuxT -> next = ListHead;
    ListHead = AuxT;
  }
  return ListHead;
}

void printLista(DeckData *ListHead, char **argv){

  DeckData *Print;
  int NeedEnter = 0;

  for (Print = ListHead; Print != NULL; Print = Print -> next){
    if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
      fprintf(Write, "%s ", Print -> card);
    }else{
      printf("%s ", Print -> card);
    }
    NeedEnter++;
    if(NeedEnter%13 == 0){
      if(argv[3] != NULL && strcmp(argv[3], "-o") == 0){
        fprintf(Write, "\n");
      }else{
        printf("\n");
      }
    }
  }
}

void freeList(DeckData *ListFree){
  DeckData *Aux;

  Aux = ListFree;
  while( ListFree != NULL){
    Aux = ListFree;
    ListFree = ListFree->next;
    free(Aux);
  }
}
